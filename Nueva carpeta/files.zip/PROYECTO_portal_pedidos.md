# Proyecto: Portal de pedidos B2B — Huevos Mateos

Documento de seguimiento. Resume todas las decisiones tomadas para poder
retomar el proyecto más adelante sin perder el hilo.

---

## 1. Qué estamos construyendo

Un **portal de pedidos B2B** (no una tienda de pago) para clientes
profesionales. Los clientes entran con su email, ven el catálogo con SUS
precios, y hacen pedidos/encargos. El importe es **estimado**; el importe
final lo sigue poniendo el ERP al pesar/facturar (como ahora).

- Clientes: ~100-200
- Productos: ~400
- No hay pago online: es pedido/encargo a confirmar.

## 2. Decisión de arquitectura

**Opción elegida: B — Web actual + backend a medida.**

Motivo: lo más importante es que **encaje exacto** como trabajan, y hay
capacidad de tocar código con guía. WooCommerce se descartó porque obligaría
a forzar la herramienta (desactivar pago, varios plugins) para algo que no es
su propósito.

La seguridad de los datos (preocupación principal) se resuelve usando
**Supabase** (base de datos PostgreSQL + login de usuarios gestionado).
Plan gratuito suficiente para este volumen. La parte sensible (contraseñas,
autenticación) la mantiene Supabase, no el usuario.

## 3. Modelo de datos del ERP (origen, en Access)

- **Articulos**: cada producto tiene 4 precios de tarifa:
  - `PrecioVenta` = tarifa 0
  - `PrecioVentasinIVA1` = tarifa 1
  - `PrecioVentasinIVA2` = tarifa 2
  - `PrecioVentasinIVA3` = tarifa 3
- **Clientes**: campo `TarifaPrecio` indica qué tarifa (0-3) le toca al cliente.
  También hay un **Dto. Cliente** (ej. 10%) que se resta al final del pedido.
- **ArticuloCliente** (tabla de ofertas):
  - `Automatico = 0`  -> el cliente tiene precio especial; se aplica `PrecioOferta`.
  - `Automatico = -1` -> NO hay precio especial; se ignora la fila (el PrecioOferta
    que aparezca es residual). Se aplica el precio de tarifa del cliente.
- Códigos con ceros a la izquierda (cliente `1117`, artículo `0510`): se tratan
  como **texto** para conservarlos.
- Artículos 9999 / 9990 / 5005: comentarios u obsoletos -> se marcan inactivos.

## 4. Regla de precio (cómo se calcula el precio de un cliente para un artículo)

1. ¿Existe fila en ofertas (Automatico=0) para ese cliente + artículo?
   - Sí -> usar `precio_oferta`.
   - No -> usar la columna de tarifa del artículo según la tarifa del cliente.
2. Al final del pedido se resta el **descuento de cliente** (%).

## 5. Formas de pedir (variantes)

- Normalmente se pide **por CAJA** (forma principal).
- **Solo algunos** productos tienen variantes: además de caja, se pueden pedir
  por **unidad** o por **kilo**.
- La **unidad monetaria** es la base del importe: importe = unidades_reales × precio.
  Ejemplo (pollo 0510): se factura por **kg**; la caja "tiene 8 pollos" es solo
  informativo; el peso es variable (15,50 kg, 16,28 kg...).
- El cliente puede pedir: 1 caja (normal), 4 pollos (variante), o 10 kg (variante).

### Regla importante de precios en variantes
- El **precio de oferta** (cliente-artículo) **solo aplica a la forma CAJA**.
- El resto de variantes (unidad, kilo) reciben **solo el precio de tarifa** del cliente.

### Importe ESTIMADO con peso medio
- Para productos por peso, SÍ se usará un **peso medio orientativo** (por caja y
  por unidad) para mostrar un importe estimado en todas las formas de pedir.
- El importe mostrado es **orientativo**; el definitivo lo pone el ERP al pesar.
  Esto debe quedar claro en la web (etiqueta tipo "importe estimado").

## 6. Acceso de clientes

- Login por **email + contraseña/PIN**.
- Las contraseñas dejarán de estar en el HTML; las gestiona Supabase cifradas.
- **Pendiente de decidir** (fase login): si cada cliente elige su contraseña o
  se le asigna inicialmente; y recuperación por email.
- **Emails: hay que completarlos.** No todos los clientes tienen email todavía.
  Plan: arrancar con los que ya lo tienen e ir añadiendo el resto. El diseño
  permite emails vacíos de momento.

## 7. Datos del ERP -> cómo se extraen

- El ERP es Access. La extracción se hará con el **script Python que ya existe**
  (`actualizar_web.py`), adaptándolo para volcar a Supabase en vez de (o además
  de) generar HTML. El "cerebro" sigue siendo el ERP.

---

## 8. Plan por fases

- **Fase 1 — Catálogo "pedible"** (frontend, sin datos sensibles): añadir carrito
  de pedido a la web, con selector de forma (caja/unidad/kilo), cantidad e importe
  estimado, panel "Mi pedido" y botón de enviar. Se puede empezar sin tocar servidores.
- **Fase 2 — Seguridad / datos** (EN CURSO): mover clientes, tarifas y ofertas a
  Supabase; login real; cada cliente solo ve SUS precios.
- **Fase 3 — Conectar el ERP**: adaptar `actualizar_web.py` para volcar datos a Supabase.
- **Fase 4 — Recepción de pedidos**: que los pedidos lleguen por email o en un
  formato que el ERP pueda leer para generar el albarán.

---

## 9. ESTADO ACTUAL / por dónde retomar

Estamos en la **Fase 2**, en el diseño de la base de datos.

**HECHO:**
- Modelo de datos cerrado (ver secciones 3-6).
- Script SQL de creación de tablas escrito: `01_crear_tablas.sql`
  (4 tablas: articulos, clientes, ofertas, formas_pedido). NO ejecutado aún.

**PENDIENTE DE VALIDAR (antes de ejecutar el SQL):**
1. Confirmar el cálculo del importe estimado para 1 caja de pollo:
   precio/kg × peso_medio_caja (ej. 16) × (1 − descuento). ¿Correcto?
2. Confirmar que códigos de cliente/artículo son texto (con ceros a la izquierda).
3. Decidir si el siguiente paso es crear las reglas de seguridad **RLS**
   (Row Level Security: que cada cliente solo lea SUS ofertas) antes de migrar datos.

**SIGUIENTES PASOS (cuando se retome):**
- Validar los 3 puntos de arriba.
- Crear cuenta en Supabase (primera vez) + proyecto. Guía de clics pendiente.
- Ejecutar `01_crear_tablas.sql` en el SQL Editor de Supabase.
- Definir reglas RLS de seguridad.
- Adaptar Python para migrar datos.

---

## 10. Archivos del proyecto

- `01_crear_tablas.sql` — esquema de tablas para Supabase (pendiente de ejecutar).
- `tiendaconprecio.html` — web actual funcionando (catálogo con precios, login,
  habituales). Base sobre la que se construirá el portal.
- `tienda.html` — versión pública sin precios.
- `actualizar_web.py` — script que genera la web desde el ERP (a adaptar en Fase 3).
