-- ============================================================
--  HUEVOS MATEOS - Portal de pedidos B2B
--  Script 01: creación de tablas (esquema de datos)
--  Plataforma: Supabase (PostgreSQL)
--  -----------------------------------------------------------
--  Refleja el modelo del ERP:
--   - articulos: 4 tarifas por producto (0,1,2,3)
--   - clientes:  tarifa base + descuento de cliente + email (login)
--   - ofertas:   tabla ArticuloCliente con Automatico=0 (precio especial)
--   - formas_pedido: caja (principal) + variantes (unidad/kilo) con
--                    conversión a la unidad monetaria y peso medio
-- ============================================================

-- Para poder re-ejecutar el script sin errores durante las pruebas,
-- borramos las tablas si ya existían (en orden inverso por dependencias).
drop table if exists formas_pedido;
drop table if exists ofertas;
drop table if exists clientes;
drop table if exists articulos;


-- ------------------------------------------------------------
-- 1) ARTICULOS  (equivale a tu tabla "Articulos")
-- ------------------------------------------------------------
create table articulos (
  codigo        text primary key,             -- ej. '0510'
  descripcion   text not null,                -- ej. 'POLLO ...'
  precio_t0     numeric(10,4) default 0,       -- PrecioVenta        (tarifa 0)
  precio_t1     numeric(10,4) default 0,       -- PrecioVentasinIVA1 (tarifa 1)
  precio_t2     numeric(10,4) default 0,       -- PrecioVentasinIVA2 (tarifa 2)
  precio_t3     numeric(10,4) default 0,       -- PrecioVentasinIVA3 (tarifa 3)
  unidad_monetaria text default 'ud',          -- sobre qué se factura: 'kg','ud','caja','litro'...
  activo        boolean default true,          -- false para obsoletos/comentarios (9999, 9990, 5005)
  familia       text                           -- opcional, para agrupar en el catálogo
);


-- ------------------------------------------------------------
-- 2) CLIENTES  (equivale a tu tabla "Clientes")
-- ------------------------------------------------------------
create table clientes (
  codigo        text primary key,             -- ej. '1117'
  nombre        text,                         -- razón social / nombre
  email         text unique,                  -- llave de acceso al portal (puede ir vacío de momento)
  tarifa        smallint not null default 0   -- 0,1,2,3  -> qué columna de precio aplica
                check (tarifa between 0 and 3),
  descuento     numeric(5,2) default 0         -- 'Dto. Cliente' en %, se resta al final (ej. 10.00)
);


-- ------------------------------------------------------------
-- 3) OFERTAS  (equivale a "ArticuloCliente" con Automatico = 0)
--    Solo guardamos las filas que SÍ se aplican (precio especial).
--    Las de Automatico = -1 NO se suben.
-- ------------------------------------------------------------
create table ofertas (
  cliente_codigo  text not null references clientes(codigo) on delete cascade,
  articulo_codigo text not null references articulos(codigo) on delete cascade,
  precio_oferta   numeric(10,4) not null,
  primary key (cliente_codigo, articulo_codigo)   -- un precio especial por cliente+artículo
);


-- ------------------------------------------------------------
-- 4) FORMAS_PEDIDO  (tabla NUEVA)
--    Define cómo se puede pedir cada artículo.
--    Regla: SIEMPRE existe la forma 'caja' (principal). Si el artículo
--    tiene variantes, se añaden filas 'unidad' y/o 'kilo'.
--
--    - factor_unidad_monetaria: cuántas "unidades monetarias" equivale
--      esta forma, para estimar importe. Ej. pollo facturado por kg:
--        * forma 'kilo'   -> 1   (1 kg = 1 unidad monetaria)
--        * forma 'caja'   -> 16  (peso medio de una caja, en kg)
--        * forma 'unidad' -> 2   (peso medio de un pollo, en kg)
--      Para un artículo de precio fijo facturado por caja:
--        * forma 'caja'   -> 1
--    - es_principal: marca la forma 'caja' como la principal.
--    - solo_tarifa: si true, esta forma NO recibe el precio de oferta,
--      solo el de tarifa (según tu regla: la oferta solo aplica a CAJAS).
-- ------------------------------------------------------------
create table formas_pedido (
  id              bigint generated always as identity primary key,
  articulo_codigo text not null references articulos(codigo) on delete cascade,
  forma           text not null check (forma in ('caja','unidad','kilo')),
  es_principal    boolean default false,
  factor_unidad_monetaria numeric(10,4) not null default 1,  -- para el importe estimado
  solo_tarifa     boolean default false,        -- true en variantes que NO admiten oferta
  etiqueta        text,                          -- texto a mostrar, ej. 'Caja (8 pollos ~16kg)'
  unique (articulo_codigo, forma)                -- una fila por forma y artículo
);

-- Índice para buscar rápido las formas de un artículo
create index idx_formas_articulo on formas_pedido(articulo_codigo);

-- ============================================================
--  FIN del script 01. Tablas creadas y vacías, listas para migrar datos.
-- ============================================================
